--------------------README-------------------------
PACKAGE TO PLACED IN THE PROJECT DIRECTORY FOR USE